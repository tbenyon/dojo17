<div class="exlog_modal">

    <div class="exlog_close_button">
        <span>X</span>
    </div>

    <div class="exlog_loader_container">
        <div class="exlog_loader">Loading...</div>
    </div>

    <div class="exlog_test_results_inner_container">

    </div>
</div>